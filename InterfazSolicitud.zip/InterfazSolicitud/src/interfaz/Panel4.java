package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.w3c.dom.ls.LSInput;

public class Panel4 extends JPanel implements ActionListener, ListSelectionListener {
	
	public final static String CONFIRMAR= "Confirmar Acci�n";
	public final static String LISTAR= "Listar Solicitudes";


	
	private JList listaSolicitudes;
	private JButton butConfirmar;
	private JButton butListarSolicitud;
	private ButtonGroup grupoButton;
	private JLabel labgrupoBotones;
	String[] el= {"a","b","c"};
	
	
	public Panel4() {
		
		
		
		
		setSize(900, 770);
		setVisible(true);
//		 setLayout(new GridLayout(5, 1));
		setLayout(new BorderLayout());
//		setLayout(new BorderLayout());
		TitledBorder t1 = new TitledBorder("listar Solicitudes");
		setBorder(t1);
		
		labgrupoBotones = new JLabel("Cambiar Estado");
		butConfirmar= new JButton(CONFIRMAR);
		butConfirmar.setActionCommand(CONFIRMAR);
		butConfirmar.addActionListener(this);
		
		butListarSolicitud = new JButton(LISTAR);
		butListarSolicitud.setActionCommand(LISTAR);
		butListarSolicitud.addActionListener(this);
		
		
		listaSolicitudes= new JList<>(el);
		listaSolicitudes.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listaSolicitudes.addListSelectionListener(this);
		JScrollPane panelDesplazamiento = new JScrollPane(listaSolicitudes);
		
		JRadioButton b1=new JRadioButton("Activa");
		JRadioButton b2= new JRadioButton("Desactivo");
	
		grupoButton=new  ButtonGroup();
		grupoButton.add(b1);
		grupoButton.add(b2);
         setLayout(new GridLayout(3,1));
		
		
		JPanel panel2= new JPanel();
		panel2.add(labgrupoBotones);
		panel2.add(b1);
		panel2.add(b2);
		
		JPanel panel3= new JPanel();
		panel3.add(butListarSolicitud);
		panel3.add(butConfirmar);
		
		add(listaSolicitudes);
		
		add(panel2);
		add(panel3);

		
		
	}
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}





	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
//		 String selectedItem = (String) listaSolicitudes.getSelectedValue();
//		 if(selectedItem.equals("a")) {
//			 JOptionPane.showMessageDialog(null,"se selecion� este elemento "+ selectedItem);
//		 }
	}

}
