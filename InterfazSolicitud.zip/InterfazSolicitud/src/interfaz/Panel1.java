package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JCalendar;

public class Panel1 extends JPanel implements ActionListener {
	// public final static String ACTION_COMBO="combo";
	public final static String CONFIRMAR= "Confirmar Acci�n";

	private JButton butConfirmar;
	private JLabel labCedula;
	private JLabel labFuncionario;
	private JLabel labProducto;
	private JLabel LabtipoSolicitud;
	private JLabel labObservacion;
	
	
	private JTextField textCedula;
	private JTextField textFuncionario;
	private JMenu menu;
	private JComboBox comboMenu;
	private JComboBox comboProducto;
	private JTextArea AtextObservacion;
	
	private JCalendar calendario;


	public Panel1() {
		// setExtendedState(MAXIMIZED_BOTH);
		
		calendario=new JCalendar();
		butConfirmar= new JButton(CONFIRMAR);
		butConfirmar.setActionCommand(CONFIRMAR);
		butConfirmar.addActionListener(this);
		
		
		labFuncionario=new JLabel("ID Funcionario");
		labCedula = new JLabel("    Cedula");
		labProducto=new JLabel("Tipo producto");
//		labProductoCambio=new JLabel("     Cambiar Producto A");
		LabtipoSolicitud = new JLabel("tipoSolicitud");
		labObservacion = new JLabel("Observaci�n");
		textCedula = new JTextField("");
		textFuncionario=new JTextField("");
		
		
//		setLayout(new GridLayout(1, 6));
		AtextObservacion = new JTextArea(18,30);

		
		setSize(900, 770);
		setVisible(true);
//		 setLayout(new GridLayout(5, 1));
		setLayout(new BorderLayout());
//		setLayout(new BorderLayout());
		TitledBorder t1 = new TitledBorder("Gestion Solicitud");
		setBorder(t1);
		// setLayout(new BorderLayout());


		comboMenu = new JComboBox();
		comboMenu.addActionListener(this);
		comboMenu.addItem("Registrar solicitud");
		comboMenu.addItem("Cancelar solicitud");
		comboMenu.addItem("Reclamo");

		
		comboProducto= new JComboBox<>();
		comboProducto.addActionListener(this);
		comboProducto.addItem("Servicio de voz");
		comboProducto.addItem("Servicio de datos");
		comboProducto.addItem("Servicio integrado");
		
		
//		comboProductoCambio=new JComboBox();
//		comboProductoCambio.addActionListener(this);
//		comboProductoCambio.addItem("Servicio de voz");
//		comboProductoCambio.addItem("Servicio de datos");
//		comboProductoCambio.addItem("Servicio integrado");
//		


		
		JPanel panel1=new JPanel();
//		panel1.setSize(200000, 7000000);
		panel1.setLayout(new GridLayout(3, 4));
//		panel1.setBorder(new TitledBorder("Panel 1"));
		// comboMenu.setActionCommand(ACTION_COMBO);
		// comboMenu.setSelectedIndex(0);

//		panel1.add(new JLabel());
		panel1.add(LabtipoSolicitud);
		panel1.add(comboMenu);
//		panel1.add(new JLabel());
		///
//		panel1.add(new JLabel("JHJHJH"));
//		panel1.add(new JLabel("M;Mb,"));
//		panel1.add(new JLabel("MHNgbj"));
//		panel1.add(new JLabel("JHHJ"));
	////////////////////////////////
//		panel1.add(new JLabel());
	    panel1.add(labCedula);
	    panel1.add(textCedula );
//		panel1.add(new JLabel());
		////////////////////
		panel1.add(new JLabel());
		panel1.add(new JLabel());
		panel1.add(labFuncionario);
		panel1.add(textFuncionario);
	////////////////////////////
//		panel1.add(new JLabel());
		panel1.add(labProducto);
		panel1.add(comboProducto);
//		panel1.add(new JLabel());
		
		//////////
	//	
		/////////////////////////////////////////
		
//		panel1.add(new JLabel());
//		panel1.add(labProductoCambio);
//		panel1.add(comboProductoCambio);
//		panel1.add(new JLabel());

		

		panel1.add(new JLabel());
		panel1.add(new JLabel());
//		panel1.add(new JLabel());
//		panel1.add(new JLabel());

		 
	   
	   
	   
	   JPanel panel2= new JPanel();
	   
		/////segundo panel
	   panel2.setLayout(new GridLayout(2, 4));
	   
	   panel2.add(new JLabel());
	   panel2.add(new JLabel());
	   panel2.add(new JLabel());
	   panel2.add(new JLabel());

	//   panel2.add(new JLabel());
	//   panel2.add(labObservacion);
	//   panel2.add(AtextObservacion);
	//   panel2.add(new JLabel());



	   
	   
	   JPanel panel3 =new JPanel();
	   panel3.add(butConfirmar);
	   
	   JPanel  panel4= new JPanel();
	   panel4.add(calendario);
	   panel4.add(labObservacion);
	   panel4.add(AtextObservacion);
	   
	   add(panel1, BorderLayout.NORTH);
	//   add(new JLabel());
	//   add(panel2, BorderLayout.CENTER);
	   
	//   add(new JLabel(), BorderLayout.WEST);
	   add(panel3, BorderLayout.SOUTH);
	   
	   add(panel4 , BorderLayout.WEST);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// comboMenu = (JComboBox) e.getSource();
		// String name= (String)comboMenu.getSelectedItem();
		// if(name.equals("Registrar solicitud")) {
		// JOptionPane.showMessageDialog(null,"se selecion� este elemento "+ name);
		// }
	}

}